"use strict";
(self["webpackChunkhass_jupyter_ext"] = self["webpackChunkhass_jupyter_ext"] || []).push([["lib_index_js"],{

/***/ "./lib/index.js"
/*!**********************!*\
  !*** ./lib/index.js ***!
  \**********************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/apputils */ "webpack/sharing/consume/default/@jupyterlab/apputils");
/* harmony import */ var _jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _jupyterlab_mainmenu__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @jupyterlab/mainmenu */ "webpack/sharing/consume/default/@jupyterlab/mainmenu");
/* harmony import */ var _jupyterlab_mainmenu__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_mainmenu__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @lumino/widgets */ "webpack/sharing/consume/default/@lumino/widgets");
/* harmony import */ var _lumino_widgets__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_lumino_widgets__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _request__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./request */ "./lib/request.js");




const CATEGORY = 'Home Assistant';
const plugin = {
    id: 'hass-jupyter-ext:plugin',
    autoStart: true,
    requires: [_jupyterlab_apputils__WEBPACK_IMPORTED_MODULE_0__.ICommandPalette, _jupyterlab_mainmenu__WEBPACK_IMPORTED_MODULE_1__.IMainMenu],
    activate: (app, palette, mainMenu) => {
        const { commands } = app;
        const reloadCmd = 'hass-jupyter-ext:reload-yaml';
        commands.addCommand(reloadCmd, {
            label: 'Reload YAML',
            execute: async () => {
                await (0,_request__WEBPACK_IMPORTED_MODULE_3__.requestAPI)('reload-yaml', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ action: 'reload_all' })
                });
            }
        });
        palette.addItem({ command: reloadCmd, category: CATEGORY });
        const stubsCmd = 'hass-jupyter-ext:generate-stubs';
        commands.addCommand(stubsCmd, {
            label: 'Generate Pyscript Stubs',
            execute: async () => {
                await (0,_request__WEBPACK_IMPORTED_MODULE_3__.requestAPI)('generate-stubs', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: '{}'
                });
            }
        });
        palette.addItem({ command: stubsCmd, category: CATEGORY });
        // ---- HA menu ----
        const haMenu = new _lumino_widgets__WEBPACK_IMPORTED_MODULE_2__.Menu({ commands });
        haMenu.title.label = 'HA';
        haMenu.addItem({ command: reloadCmd });
        haMenu.addItem({ command: stubsCmd });
        // Add it to the main menu bar (at the end by default)
        mainMenu.addMenu(haMenu);
    }
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (plugin);


/***/ },

/***/ "./lib/request.js"
/*!************************!*\
  !*** ./lib/request.js ***!
  \************************/
(__unused_webpack_module, __webpack_exports__, __webpack_require__) {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   requestAPI: () => (/* binding */ requestAPI)
/* harmony export */ });
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @jupyterlab/services */ "webpack/sharing/consume/default/@jupyterlab/services");
/* harmony import */ var _jupyterlab_services__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_jupyterlab_services__WEBPACK_IMPORTED_MODULE_0__);
// src/request.ts

const NAMESPACE = 'hass-jupyter-ext';
async function requestAPI(endpoint, init = {}) {
    const settings = _jupyterlab_services__WEBPACK_IMPORTED_MODULE_0__.ServerConnection.makeSettings();
    const requestUrl = `${settings.baseUrl}${NAMESPACE}/${endpoint}`;
    const response = await _jupyterlab_services__WEBPACK_IMPORTED_MODULE_0__.ServerConnection.makeRequest(requestUrl, init, settings);
    if (!response.ok) {
        const text = await response.text();
        throw new _jupyterlab_services__WEBPACK_IMPORTED_MODULE_0__.ServerConnection.ResponseError(response, text);
    }
    // Some endpoints might return empty bodies; if yours always returns JSON, this is fine.
    return response.json();
}


/***/ }

}]);
//# sourceMappingURL=lib_index_js.f92f89fd26c93928c534.js.map