from jupyter_server.base.handlers import APIHandler
from tornado import web

from .ha import ha_post


class HAReloadYAMLHandler(APIHandler):
    @web.authenticated
    async def post(self):
        """
        Example endpoints (you can change to whatever you need):
          - /api/config/core/check_config (POST)  # check config
          - /api/services/homeassistant/reload_all (POST)
          - /api/services/pyscript/reload (POST)  # if pyscript exposes this service
        """
        body = self.get_json_body() or {}
        action = body.get("action", "reload_all")

        if action == "reload_all":
            result = await ha_post("/api/services/homeassistant/reload_all")
        elif action == "check_config":
            result = await ha_post("/api/services/homeassistant/check_config")
        else:
            raise web.HTTPError(400, f"Unknown action: {action}")

        self.finish({"ok": True, "result": result})


class HARegeneratePyscriptStubsHandler(APIHandler):
    @web.authenticated
    async def post(self):
        """
        This is intentionally generic. You have a few options:

        A) Call a HA service that *you* implement in pyscript, e.g.
           service: pyscript.regen_stubs

        B) If your stub generation is local (runs inside this Jupyter container),
           don’t call HA at all here — just run the local generator command.

        Below shows option A (HA service call).
        """
        result = await ha_post("/api/services/pyscript/generate_stubs")
        self.finish({"ok": True, "result": result})