from jupyter_server.utils import url_path_join

from .handlers import HAReloadYAMLHandler, HARegeneratePyscriptStubsHandler


def _jupyter_server_extension_points():
    return [{"module": "my_ha_tools.serverextension"}]


def load_jupyter_server_extension(server_app):
    web_app = server_app.web_app
    base_url = web_app.settings["base_url"]

    host_pattern = ".*$"
    routes = [
        (url_path_join(base_url, "my-ha-tools", "reload-yaml"), HAReloadYAMLHandler),
        (url_path_join(base_url, "my-ha-tools", "regen-stubs"), HARegeneratePyscriptStubsHandler),
    ]

    web_app.add_handlers(host_pattern, routes)
    server_app.log.info("my-ha-tools server extension loaded")
    