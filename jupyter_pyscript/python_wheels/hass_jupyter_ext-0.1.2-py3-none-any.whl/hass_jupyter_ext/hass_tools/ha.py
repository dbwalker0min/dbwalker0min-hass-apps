import os
from dataclasses import dataclass
from urllib.parse import urljoin

import httpx


@dataclass(frozen=True)
class HAConfig:
    host: str
    url: str
    token: str

    @staticmethod
    def from_env() -> "HAConfig":
        host = os.environ.get("HASS_HOST", "").strip()
        url = os.environ.get("HASS_URL", "").strip()
        token = os.environ.get("HASS_TOKEN", "").strip()

        missing = [k for k, v in [("HASS_HOST", host), ("HASS_URL", url), ("HASS_TOKEN", token)] if not v]
        if missing:
            raise RuntimeError(f"Missing required environment variables: {', '.join(missing)}")

        return HAConfig(host=host, url=url.rstrip("/"), token=token)


def _headers(token: str) -> dict:
    return {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json",
    }


async def ha_post(path: str, json: dict | None = None) -> dict:
    cfg = HAConfig.from_env()
    base = cfg.url + "/"
    endpoint = urljoin(base, path.lstrip("/"))

    async with httpx.AsyncClient(timeout=15.0) as client:
        resp = await client.post(endpoint, headers=_headers(cfg.token), json=json or {})
        # Return useful diagnostics on failure
        if resp.status_code >= 400:
            detail = None
            try:
                detail = resp.json()
            except Exception:
                detail = resp.text
            raise RuntimeError(f"HA POST {endpoint} failed: {resp.status_code} {detail}")
        # Some HA endpoints return JSON, some return empty/204
        if resp.status_code == 204 or not resp.content:
            return {"ok": True}
        return resp.json()