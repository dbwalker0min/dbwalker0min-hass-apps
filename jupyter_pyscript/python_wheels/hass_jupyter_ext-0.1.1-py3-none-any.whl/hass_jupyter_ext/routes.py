# hass_jupyter_ext/routes.py

from jupyter_server.base.handlers import APIHandler
from jupyter_server.utils import url_path_join
from tornado import web

from .hass_tools.ha import ha_post  # uses HA_HOST / HA_URL / HA_TOKEN from env


class ReloadYAMLHandler(APIHandler):
    @web.authenticated
    async def post(self):
        body = self.get_json_body() or {}
        action = body.get("action", "reload_all")

        if action == "reload_all":
            result = await ha_post("/api/services/homeassistant/reload_all")
        elif action == "check_config":
            result = await ha_post("/api/config/core/check_config")
        else:
            raise web.HTTPError(400, f"Unknown action: {action}")

        self.finish({"ok": True, "result": result})


class GenerateStubsHandler(APIHandler):
    @web.authenticated
    async def post(self):
        try:
            # pyscript service: generate_stubs
            result = await ha_post("/api/services/pyscript/generate_stubs?return_response")
            self.finish({"ok": True, "result": result})
        except Exception as e:
            self.set_status(500)
            self.finish({"ok": False, "error": str(e)})



def setup_route_handlers(web_app):
    base_url = web_app.settings["base_url"]
    # This is the URL prefix your frontend will call:
    #   <baseUrl>/hass-jupyter-ext/...
    route_base = url_path_join(base_url, "hass-jupyter-ext")

    handlers = [
        (url_path_join(route_base, "reload-yaml"), ReloadYAMLHandler),
        (url_path_join(route_base, "generate-stubs"), GenerateStubsHandler),
    ]

    web_app.add_handlers(".*$", handlers)
